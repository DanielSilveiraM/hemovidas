# Apresentação

<span style="color:red">Pré-requisitos: Todos os demais artefatos</span>

>Slide feito com a apresentação do projeto.

![Slide](images/Doacao_de_Sangue.pdf)

## Título do Projeto
> Salve Vidas!

>![Logo](images/salveVidas.png)


## Identidade Visual 
>Cores mais avermelhadas seguindo um padrão nos slides.
>Apresentação de imagens de onde foi reunido as ideias do projeto (Miro).
>Apresentação do userflow para a melhor compreensão do projeto.

## Conjunto de Slides (Estrutura)
>Introdução com o título, integrantes do grupo e professor responsável.


>Sumário com os assuntos a serem tratados nos próximos slides.


>Introdução aos problemas fundados.


>Metodologia da Persona (Mapa de Empatia).


>Identidade visual da pagina inicial do site.


>Userflow do site.


>Conclusão do projeto, junto a uma fonte de divulgação via WhatsApp.
