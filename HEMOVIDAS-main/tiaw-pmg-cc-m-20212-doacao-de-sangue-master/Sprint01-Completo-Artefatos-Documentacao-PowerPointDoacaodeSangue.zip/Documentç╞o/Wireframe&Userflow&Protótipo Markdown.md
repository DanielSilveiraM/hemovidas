
# User flow

![UserFlow](images/userflow.jpg)


# Wireframes
<br>

![](images/home.png)

![](images/login.png)

![](images/Cadastro.png)

![](images/Perfildousuario.png)

![](images/Perfildocentro.png)

![](images/Informacaodocentro.png)

![](images/Agendacoleta.png)

![](images/Centros.png)

![](images/SobreNos.png)
<br>

# Protótipo

>https://www.figma.com/proto/4ffq1mb2qRNtL5FlDXU6kJ/Prot%C3%B3tipo-Doa%C3%A7%C3%A3o-Sangue?node-id=64%3A342&scaling=min-zoom&page-id=64%3A341&starting-point-node-id=64%3A342