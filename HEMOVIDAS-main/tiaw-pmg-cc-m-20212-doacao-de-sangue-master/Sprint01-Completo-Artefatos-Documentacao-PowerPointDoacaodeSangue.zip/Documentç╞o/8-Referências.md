# Referências

>Requisitos básicos para doação de sangue - Hemocentro São Paulo. Disponível em: (http://www.prosangue.sp.gov.br/artigos/requisitos_basicos_para_doacao.html). Acesso em: (29/09/2021).

>GOV.BR - Doação de sangue. Disponível em:(https://www.gov.br/saude/pt-br/composicao/saes/sangue). Acesso em: (29/09/2021).

