# Artefatos do projeto

>Elaborado no Miro:
Matriz de Alinhamento CSD,Mapa de Stakeholders,Personas, Mapas de Empatia,Requisitor Funcionais e Não Funcionais.

<br>

![](images/DoaçãodeSangue.jpg)

![](images/DoaçãodeSangue(1).jpg)

![](images/DoaçãodeSangue(2).jpg)

![](images/DoaçãodeSangue(3).jpg)

![](images/DoaçãodeSangue(4).jpg)

![](images/DoaçãodeSangue(5).jpg)

![](images/DoaçãodeSangue(6).jpg)

![](images/DoaçãodeSangue(7).jpg)

![](images/DoaçãodeSangue(8).jpg)

![](images/DoaçãodeSangue(9).jpg)
